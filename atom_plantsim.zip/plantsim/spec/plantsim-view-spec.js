'use babel';

import PlantsimView from '../lib/plantsim-view';

describe('PlantsimView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
